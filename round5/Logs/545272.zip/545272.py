from datamodel import OrderDepth, UserId, TradingState, Order
from typing import List, Dict, Any
import jsonpickle
import math


class Trader:

    POS_LIMIT = 10

    def run(self, state: TradingState):
        # ── Restore state ──
        if state.traderData and state.traderData != '':
            try:
                saved = jsonpickle.decode(state.traderData)
                emas = saved.get('e', {})
            except:
                emas = {}
        else:
            emas = {}

        result = {}

        for product in state.order_depths:
            order_depth = state.order_depths[product]
            orders: List[Order] = []

            if not order_depth.buy_orders or not order_depth.sell_orders:
                result[product] = orders
                continue

            best_bid = max(order_depth.buy_orders.keys())
            best_ask = min(order_depth.sell_orders.keys())
            spread = best_ask - best_bid
            mid = (best_bid + best_ask) / 2.0

            # ── EMA fair value ──
            alpha = 0.15
            if product in emas:
                emas[product] = alpha * mid + (1 - alpha) * emas[product]
            else:
                emas[product] = mid

            fair = emas[product]

            # ── Position ──
            pos = state.position.get(product, 0)
            buy_budget = self.POS_LIMIT - pos
            sell_budget = self.POS_LIMIT + pos
            buy_used = 0
            sell_used = 0

            # ── PHASE 1: Only sweep orders that are CLEARLY mispriced ──
            # The key insight: only take if price is at least half-spread
            # away from fair. This prevents getting adversely selected.
            half_spread = spread / 2.0

            if order_depth.sell_orders:
                for ask_price in sorted(order_depth.sell_orders.keys()):
                    remaining = buy_budget - buy_used
                    # Only buy if ask is significantly below fair
                    if ask_price < fair - half_spread and remaining > 0:
                        vol = min(-order_depth.sell_orders[ask_price], remaining)
                        if vol > 0:
                            orders.append(Order(product, ask_price, vol))
                            buy_used += vol

            if order_depth.buy_orders:
                for bid_price in sorted(order_depth.buy_orders.keys(), reverse=True):
                    remaining = sell_budget - sell_used
                    # Only sell if bid is significantly above fair
                    if bid_price > fair + half_spread and remaining > 0:
                        vol = min(order_depth.buy_orders[bid_price], remaining)
                        if vol > 0:
                            orders.append(Order(product, bid_price, -vol))
                            sell_used += vol

            # ── PHASE 2: Passive quotes AT the best bid/ask ──
            # Don't try to improve the spread. Just join the queue.
            # This way we only get filled when there's genuine flow.
            # Inventory skew: shift prices to unwind position
            pos_frac = pos / self.POS_LIMIT  # -1 to +1

            # If we have inventory, make it easier to unwind
            if pos > 0:
                # Long: more eager to sell, less eager to buy
                quote_bid = best_bid - 1
                quote_ask = best_ask
            elif pos < 0:
                # Short: more eager to buy, less eager to sell
                quote_bid = best_bid
                quote_ask = best_ask + 1
            else:
                # Flat: quote at best bid/ask
                quote_bid = best_bid
                quote_ask = best_ask

            remaining_buy = buy_budget - buy_used
            remaining_sell = sell_budget - sell_used

            # Cap passive quote size to avoid building too much inventory
            passive_size = min(3, remaining_buy)
            if passive_size > 0:
                orders.append(Order(product, quote_bid, passive_size))

            passive_size = min(3, remaining_sell)
            if passive_size > 0:
                orders.append(Order(product, quote_ask, -passive_size))

            result[product] = orders

        traderData = jsonpickle.encode({'e': emas})
        conversions = 0
        return result, conversions, traderData