from datamodel import OrderDepth, UserId, TradingState, Order
from typing import List, Dict, Any
import jsonpickle
import math


class Trader:

    # All 50 products, position limit = 10 for all
    POS_LIMIT = 10

    # Group classification from data analysis
    # High-vol groups need wider spreads
    GROUP_CONFIG = {
        # (spread_edge, max_quote_size, ema_alpha)
        'PEBBLES':      (3, 3, 0.05),   # highest vol (0.18), wide spreads
        'MICROCHIP':    (2, 3, 0.05),   # high vol (0.14)
        'OXYGEN_SHAKE': (2, 3, 0.08),   # moderate vol, wide spreads
        'ROBOT':        (2, 4, 0.08),   # moderate vol, tight spreads
        'GALAXY_SOUNDS':(2, 3, 0.08),   # moderate vol
        'UV_VISOR':     (2, 3, 0.08),   # moderate vol
        'SLEEP_POD':    (2, 4, 0.08),   # moderate vol, tight spreads
        'TRANSLATOR':   (2, 4, 0.08),   # moderate vol, tight spreads
        'PANEL':        (2, 4, 0.08),   # moderate vol, tight spreads
        'SNACKPACK':    (3, 3, 0.10),   # lowest vol but WIDEST spread (16-17)
    }

    def get_group(self, product: str) -> str:
        for group in self.GROUP_CONFIG:
            if group in product:
                return group
        return 'DEFAULT'

    def run(self, state: TradingState):
        # Restore state
        if state.traderData and state.traderData != '':
            try:
                saved = jsonpickle.decode(state.traderData)
                emas = saved.get('emas', {})
            except:
                emas = {}
        else:
            emas = {}

        result = {}

        for product in state.order_depths:
            order_depth = state.order_depths[product]
            orders: List[Order] = []

            # Calculate mid price
            if order_depth.buy_orders and order_depth.sell_orders:
                best_bid = max(order_depth.buy_orders.keys())
                best_ask = min(order_depth.sell_orders.keys())
                mid = (best_bid + best_ask) / 2.0
            elif order_depth.buy_orders:
                mid = max(order_depth.buy_orders.keys())
            elif order_depth.sell_orders:
                mid = min(order_depth.sell_orders.keys())
            else:
                result[product] = orders
                continue

            # Update EMA fair value
            group = self.get_group(product)
            config = self.GROUP_CONFIG.get(group, (2, 3, 0.08))
            edge, max_size, alpha = config

            if product in emas:
                emas[product] = alpha * mid + (1 - alpha) * emas[product]
            else:
                emas[product] = mid

            fair = emas[product]

            # Current position
            pos = state.position.get(product, 0)

            # Inventory skew: shift fair value to discourage building more position
            # If long, lower fair to sell more easily; if short, raise fair to buy
            skew = -pos * 0.3
            fair_skewed = fair + skew

            # Calculate buy/sell capacity
            buy_capacity = self.POS_LIMIT - pos
            sell_capacity = self.POS_LIMIT + pos

            # PHASE 1: Aggressive sweep -- take any mispriced orders
            if order_depth.sell_orders:
                for ask_price in sorted(order_depth.sell_orders.keys()):
                    if ask_price < fair_skewed - 0.5 and buy_capacity > 0:
                        ask_vol = -order_depth.sell_orders[ask_price]
                        take_qty = min(ask_vol, buy_capacity)
                        orders.append(Order(product, ask_price, take_qty))
                        buy_capacity -= take_qty

            if order_depth.buy_orders:
                for bid_price in sorted(order_depth.buy_orders.keys(), reverse=True):
                    if bid_price > fair_skewed + 0.5 and sell_capacity > 0:
                        bid_vol = order_depth.buy_orders[bid_price]
                        take_qty = min(bid_vol, sell_capacity)
                        orders.append(Order(product, bid_price, -take_qty))
                        sell_capacity -= take_qty

            # PHASE 2: Passive market-making quotes
            buy_price = int(math.floor(fair_skewed - edge))
            sell_price = int(math.ceil(fair_skewed + edge))

            buy_qty = min(max_size, buy_capacity)
            sell_qty = min(max_size, sell_capacity)

            if buy_qty > 0:
                orders.append(Order(product, buy_price, buy_qty))
            if sell_qty > 0:
                orders.append(Order(product, sell_price, -sell_qty))

            result[product] = orders

        # Save state
        traderData = jsonpickle.encode({'emas': emas})
        conversions = 0
        return result, conversions, traderData