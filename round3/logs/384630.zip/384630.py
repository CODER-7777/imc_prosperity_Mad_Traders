# Mad_Traders - IMC Prosperity 4 - Round 3 "Gloves Off" Strategy
# ================================================================
# COMPLIANT WITH:
#   - Writing_an_Algorithm_in_Python.pdf (Lambda stateless, traderData, etc.)
#   - Round_3_Gloves_Off.pdf (position limits, TTE, products)
#
# PRODUCTS (Round 3 ONLY - GOAT phase, no R1/R2 carry-forward):
#   HYDROGEL_PACK           - delta-1 product, limit 200
#   VELVETFRUIT_EXTRACT     - delta-1 product, limit 200
#   VEV_XXXX (x10 strikes)  - European call options, limit 300 each
#
# TTE: 7-day expiry from Round 1.
#   Historical: day0=TTE8, day1=TTE7, day2=TTE6
#   LIVE Round 3: TTE = 5 days at start
# ================================================================

from datamodel import OrderDepth, UserId, TradingState, Order
from typing import List, Dict
import math
import json


class Trader:

    # Position limits (from Round 3 PDF)
    LIMITS = {
        "HYDROGEL_PACK": 200,
        "VELVETFRUIT_EXTRACT": 200,
        "VEV_4000": 300, "VEV_4500": 300, "VEV_5000": 300,
        "VEV_5100": 300, "VEV_5200": 300, "VEV_5300": 300,
        "VEV_5400": 300, "VEV_5500": 300, "VEV_6000": 300,
        "VEV_6500": 300,
    }

    VEV_STRIKES = {
        "VEV_4000": 4000, "VEV_4500": 4500, "VEV_5000": 5000,
        "VEV_5100": 5100, "VEV_5200": 5200, "VEV_5300": 5300,
        "VEV_5400": 5400, "VEV_5500": 5500, "VEV_6000": 6000,
        "VEV_6500": 6500,
    }

    # TTE tracking: 7-day expiry starting from Round 1
    # Historical data: day0=tutorial(TTE8), day1=R1(TTE7), day2=R2(TTE6)
    # LIVE Round 3: TTE=5 at start, decays to ~4 by end of simulation day
    TICKS_PER_DAY = 1_000_000
    TTE_START_DAYS = 5.0  # For LIVE Round 3 submission

    # Calibrated from data: VEV_5300 @ VE=5295, TTE=6d → price=58 → sigma≈0.22
    SIGMA = 0.22  # Annualized volatility

    def bid(self):
        """Round 2 MAF. Ignored for Round 3."""
        return 0

    # ===========================================================
    # BLACK-SCHOLES EUROPEAN CALL (no risk-free rate in game)
    # ===========================================================
    @staticmethod
    def bs_call(S: float, K: float, T: float, sigma: float) -> float:
        """
        European call option price.
        S: underlying price (VELVETFRUIT_EXTRACT mid)
        K: strike price
        T: time to expiry in YEARS (TTE_days / 365)
        sigma: annualized volatility
        """
        if T <= 1e-7:
            return max(0.0, S - K)
        if S <= 0 or K <= 0:
            return max(0.0, S - K)
        try:
            sqrt_T = math.sqrt(T)
            d1 = (math.log(S / K) + 0.5 * sigma * sigma * T) / (sigma * sqrt_T)
            d2 = d1 - sigma * sqrt_T
            nd1 = 0.5 * (1.0 + math.erf(d1 / 1.4142135623730951))
            nd2 = 0.5 * (1.0 + math.erf(d2 / 1.4142135623730951))
            return S * nd1 - K * nd2
        except (ValueError, ZeroDivisionError):
            return max(0.0, S - K)

    @staticmethod
    def bs_delta(S: float, K: float, T: float, sigma: float) -> float:
        """Delta of European call option (for hedging)."""
        if T <= 1e-7:
            return 1.0 if S > K else 0.0
        if S <= 0 or K <= 0:
            return 1.0 if S > K else 0.0
        try:
            sqrt_T = math.sqrt(T)
            d1 = (math.log(S / K) + 0.5 * sigma * sigma * T) / (sigma * sqrt_T)
            return 0.5 * (1.0 + math.erf(d1 / 1.4142135623730951))
        except (ValueError, ZeroDivisionError):
            return 1.0 if S > K else 0.0

    # ===========================================================
    # HELPER: Safe mid price
    # ===========================================================
    @staticmethod
    def get_mid(od: OrderDepth) -> float:
        if od.buy_orders and od.sell_orders:
            return (max(od.buy_orders.keys()) + min(od.sell_orders.keys())) / 2.0
        return 0.0

    # ===========================================================
    # STRATEGY: Mean-reversion market-maker (HYDROGEL & VE)
    # ===========================================================
    def mean_reversion(self, product: str, od: OrderDepth, pos: int,
                       limit: int, fv: float, spread: int = 2, skew_k: float = 3.0):
        orders: List[Order] = []
        cur_pos = pos

        best_bid = max(od.buy_orders.keys()) if od.buy_orders else None
        best_ask = min(od.sell_orders.keys()) if od.sell_orders else None
        if best_bid is None or best_ask is None:
            return orders

        # PHASE 1: TAKE mispriced asks (buy cheap)
        for ask_price in sorted(od.sell_orders.keys()):
            if ask_price < fv and cur_pos < limit:
                ask_vol = -od.sell_orders[ask_price]  # make positive
                buy_qty = min(ask_vol, limit - cur_pos)
                if buy_qty > 0:
                    orders.append(Order(product, ask_price, buy_qty))
                    cur_pos += buy_qty

        # PHASE 1: TAKE mispriced bids (sell expensive)
        for bid_price in sorted(od.buy_orders.keys(), reverse=True):
            if bid_price > fv and cur_pos > -limit:
                bid_vol = od.buy_orders[bid_price]
                sell_qty = min(bid_vol, cur_pos + limit)
                if sell_qty > 0:
                    orders.append(Order(product, bid_price, -sell_qty))
                    cur_pos -= sell_qty

        # PHASE 2: MAKE with inventory skew
        inv_ratio = cur_pos / limit if limit > 0 else 0
        skew = -int(inv_ratio * skew_k)

        my_bid = int(round(fv)) - spread + skew
        my_ask = int(round(fv)) + spread + skew

        # Don't cross the market
        my_bid = min(my_bid, best_bid + 1)
        my_ask = max(my_ask, best_ask - 1)

        buy_room = limit - cur_pos
        sell_room = limit + cur_pos

        if buy_room > 0:
            orders.append(Order(product, my_bid, buy_room))
        if sell_room > 0:
            orders.append(Order(product, my_ask, -sell_room))

        return orders

    # ===========================================================
    # STRATEGY: VEV Options Black-Scholes sniping
    # ===========================================================
    def trade_vev(self, product: str, od: OrderDepth, pos: int,
                  limit: int, strike: int, ve_price: float, T_years: float):
        orders: List[Order] = []
        cur_pos = pos

        best_bid = max(od.buy_orders.keys()) if od.buy_orders else None
        best_ask = min(od.sell_orders.keys()) if od.sell_orders else None
        if best_bid is None or best_ask is None:
            return orders

        # Calculate BS fair value
        fv = self.bs_call(ve_price, float(strike), T_years, self.SIGMA)

        # Floor at intrinsic value (European call can't trade below intrinsic)
        intrinsic = max(0.0, ve_price - strike)
        fv = max(fv, intrinsic)

        # Skip deep OTM worthless options — no edge to extract
        if fv < 0.3 and strike > ve_price + 300:
            return orders

        # TAKE: Buy when market ask is significantly below fair value
        edge = max(1.0, fv * 0.02)  # Minimum 1 tick or 2% of FV

        for ask_price in sorted(od.sell_orders.keys()):
            if ask_price < fv - edge and cur_pos < limit:
                ask_vol = -od.sell_orders[ask_price]
                buy_qty = min(ask_vol, limit - cur_pos)
                if buy_qty > 0:
                    orders.append(Order(product, ask_price, buy_qty))
                    cur_pos += buy_qty

        # TAKE: Sell when market bid is significantly above fair value
        for bid_price in sorted(od.buy_orders.keys(), reverse=True):
            if bid_price > fv + edge and cur_pos > -limit:
                bid_vol = od.buy_orders[bid_price]
                sell_qty = min(bid_vol, cur_pos + limit)
                if sell_qty > 0:
                    orders.append(Order(product, bid_price, -sell_qty))
                    cur_pos -= sell_qty

        # MAKE: Quote around fair value with inventory skew
        inv_ratio = cur_pos / limit if limit > 0 else 0
        skew = -int(inv_ratio * 3)

        fv_int = int(round(fv))
        my_bid = max(0, fv_int - 2 + skew)
        my_ask = max(1, fv_int + 2 + skew)

        # Don't cross the market
        my_bid = min(my_bid, best_bid + 1)
        my_ask = max(my_ask, best_ask - 1)

        # Market-making lot size: cap to avoid position blowup
        buy_room = limit - cur_pos
        sell_room = cur_pos + limit
        mm_buy = min(40, buy_room)
        mm_sell = min(40, sell_room)

        if my_bid > 0 and mm_buy > 0:
            orders.append(Order(product, my_bid, mm_buy))
        if my_ask > 0 and mm_sell > 0:
            orders.append(Order(product, my_ask, -mm_sell))

        return orders

    # ===========================================================
    # MAIN RUN
    # ===========================================================
    def run(self, state: TradingState):
        result: Dict[str, List[Order]] = {}

        # ---- RESTORE STATE (Lambda is stateless!) ----
        ema = {}
        day = 0
        last_ts = -1

        if state.traderData and state.traderData != "":
            try:
                saved = json.loads(state.traderData)
                ema = saved.get("ema", {})
                day = saved.get("day", 0)
                last_ts = saved.get("last_ts", -1)
            except Exception:
                pass

        # ---- DETECT DAY TRANSITION ----
        if 0 < last_ts and state.timestamp < last_ts:
            day += 1

        # ---- GET VELVETFRUIT EXTRACT MID PRICE ----
        ve_mid = 5250.0
        if "VELVETFRUIT_EXTRACT" in state.order_depths:
            m = self.get_mid(state.order_depths["VELVETFRUIT_EXTRACT"])
            if m > 0:
                ve_mid = m

        # ---- UPDATE EMAs (slow alpha for fair value tracking) ----
        alpha = 0.005
        for prod in ["VELVETFRUIT_EXTRACT", "HYDROGEL_PACK"]:
            if prod in state.order_depths:
                mid = self.get_mid(state.order_depths[prod])
                if mid > 0:
                    if prod in ema:
                        ema[prod] = alpha * mid + (1.0 - alpha) * ema[prod]
                    else:
                        ema[prod] = mid

        # ---- CALCULATE TTE FOR OPTIONS ----
        # TTE = TTE_START - day_offset - fraction_of_current_day
        # For LIVE R3: TTE_START=5, day always 0 (single simulation day)
        # For historical testing: day increments as data progresses
        intraday_fraction = state.timestamp / self.TICKS_PER_DAY
        tte_days = self.TTE_START_DAYS - day - intraday_fraction
        tte_days = max(tte_days, 0.01)  # floor to avoid div-by-zero
        T_years = tte_days / 365.0

        # ---- TRADE EACH PRODUCT ----
        for product in state.order_depths:
            od = state.order_depths[product]
            pos = state.position.get(product, 0)
            limit = self.LIMITS.get(product, 50)

            if not od.buy_orders or not od.sell_orders:
                result[product] = []
                continue

            if product == "HYDROGEL_PACK":
                # Mean-reversion around EMA-tracked fair value
                fv = ema.get("HYDROGEL_PACK", self.get_mid(od))
                result[product] = self.mean_reversion(
                    product, od, pos, limit, fv=fv, spread=3, skew_k=4.0)

            elif product == "VELVETFRUIT_EXTRACT":
                # Mean-reversion with EMA tracking (VE drifts ~15/day upward)
                fv = ema.get("VELVETFRUIT_EXTRACT", ve_mid)
                result[product] = self.mean_reversion(
                    product, od, pos, limit, fv=fv, spread=2, skew_k=3.0)

            elif product in self.VEV_STRIKES:
                # Black-Scholes fair-value sniping on European call options
                strike = self.VEV_STRIKES[product]
                result[product] = self.trade_vev(
                    product, od, pos, limit, strike, ve_mid, T_years)

            else:
                result[product] = []

        # ---- SAVE STATE (must be under 50,000 chars) ----
        conversions = 0
        trader_data = json.dumps({
            "ema": ema,
            "day": day,
            "last_ts": state.timestamp,
        })

        return result, conversions, trader_data