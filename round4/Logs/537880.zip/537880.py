"""
Round 4 Trader — IMC Prosperity (V2 AGGRESSIVE)
=================================================
Target: 35,000+ PnL

Key insight from V1 logs (22,568 PnL):
  - VEV_5100/5200/5300 = +23,182 (98% of profits)
  - VE delta hedge cost = -3,705 (unnecessary drag)
  - HP market-making = -567 (spreads too wide)

V2 changes:
  1. Sweep ENTIRE VEV order book, not just best level
  2. Increase max size per VEV from 10 → 50
  3. Tighten VEV edge from 3 → 1 (trade more often)
  4. Reduce position buffer from 25 → 5
  5. Only delta-hedge when exposure > 50 (reduce hedge drag)
  6. HP: tighter spread (±4), bigger passive size (40)
  7. VE: tighter spread (±2), bigger passive size (30)
  8. Faster EMA (alpha=0.15) for quicker reaction
"""

from datamodel import (
    OrderDepth, TradingState, Order, Trade,
    Symbol, Product, Position, Listing, Observation
)
from typing import Dict, List, Optional, Tuple
import math
import json


# ─── Constants ────────────────────────────────────────────────────────────────

PRODUCTS = ["HYDROGEL_PACK", "VELVETFRUIT_EXTRACT"]
VEV_STRIKES = [4000, 4500, 5000, 5100, 5200, 5300, 5400, 5500, 6000, 6500]
VEV_SYMBOLS = [f"VEV_{k}" for k in VEV_STRIKES]

POSITION_LIMITS = {
    "HYDROGEL_PACK":          200,
    "VELVETFRUIT_EXTRACT":    200,
    **{f"VEV_{k}": 300 for k in VEV_STRIKES},
}

# V2: Reduced buffer to use more of position limit
BUFFER = 5

# V2: Faster EMA for quicker fair value updates
EMA_ALPHA = 0.15

# V2: Tighter spreads for more fills
HP_HALF_SPREAD   = 4     # was 8
VF_HALF_SPREAD   = 2     # was 3
VEV_EDGE         = 1     # was 3 — trade any mispricing > 1 tick

# V2: Larger passive quote sizes
HP_PASSIVE_SIZE  = 40    # was 20
VF_PASSIVE_SIZE  = 30    # was 15
VEV_MAX_PER_LEVEL = 50   # was 10 — sweep harder

# Realized vol
VF_REALIZED_VOL  = 0.055
VEV_DAYS_TOTAL   = 4
STEPS_PER_DAY    = 1000
STEPS_PER_YEAR   = 252 * STEPS_PER_DAY

# V2: Only hedge when net delta exceeds this threshold
DELTA_HEDGE_THRESHOLD = 50


# ─── Utilities ────────────────────────────────────────────────────────────────

def black_scholes_call(S: float, K: float, T: float, sigma: float) -> float:
    """Black-Scholes call price (risk-neutral drift = 0)."""
    if T <= 0 or S <= 0:
        return max(S - K, 0.0)
    d1 = (math.log(S / K) + 0.5 * sigma ** 2 * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)
    return S * _norm_cdf(d1) - K * _norm_cdf(d2)


def bs_call_delta(S: float, K: float, T: float, sigma: float) -> float:
    """Delta of a BS call."""
    if T <= 0 or S <= 0:
        return 1.0 if S > K else 0.0
    d1 = (math.log(S / K) + 0.5 * sigma ** 2 * T) / (sigma * math.sqrt(T))
    return _norm_cdf(d1)


def _norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2)))


def mid_price(od: OrderDepth) -> Optional[float]:
    if od.buy_orders and od.sell_orders:
        best_bid = max(od.buy_orders)
        best_ask = min(od.sell_orders)
        return (best_bid + best_ask) / 2
    if od.buy_orders:
        return max(od.buy_orders)
    if od.sell_orders:
        return min(od.sell_orders)
    return None


def best_bid(od: OrderDepth) -> Optional[int]:
    return max(od.buy_orders) if od.buy_orders else None


def best_ask(od: OrderDepth) -> Optional[int]:
    return min(od.sell_orders) if od.sell_orders else None


def available_buy(product: str, position: int) -> int:
    limit = POSITION_LIMITS[product] - BUFFER
    return max(0, limit - position)


def available_sell(product: str, position: int) -> int:
    limit = POSITION_LIMITS[product] - BUFFER
    return max(0, limit + position)


# ─── State ────────────────────────────────────────────────────────────────────

DEFAULT_STATE = {
    "ema": {},
    "vol_sq_sum": 0.0,
    "vol_n": 0,
    "vf_sigma": VF_REALIZED_VOL,
    "last_buyer": {},
    "last_seller": {},
    "prev_mid": {},
    "timestamp": 0,
}


def load_state(raw: str) -> dict:
    if not raw:
        return DEFAULT_STATE.copy()
    try:
        return json.loads(raw)
    except Exception:
        return DEFAULT_STATE.copy()


class _SafeEncoder(json.JSONEncoder):
    def default(self, obj):
        try:
            return int(obj)
        except (TypeError, ValueError):
            pass
        try:
            return float(obj)
        except (TypeError, ValueError):
            pass
        return super().default(obj)


def save_state(state: dict) -> str:
    return json.dumps(state, cls=_SafeEncoder)


# ─── Main Trader ──────────────────────────────────────────────────────────────

class Trader:

    def bid(self):
        return 15

    def run(self, trading_state: TradingState) -> Tuple[Dict[str, List[Order]], int, str]:
        state = load_state(trading_state.traderData)
        orders: Dict[str, List[Order]] = {}
        positions: Dict[str, int] = trading_state.position or {}

        # ── 1. Update counterparty intel ────────────────────────────────────
        for symbol, trades in trading_state.market_trades.items():
            for t in trades:
                if t.buyer:
                    state["last_buyer"][symbol] = t.buyer
                if t.seller:
                    state["last_seller"][symbol] = t.seller

        # ── 2. Update EMAs & realized vol ───────────────────────────────────
        for product in PRODUCTS + VEV_SYMBOLS:
            if product not in trading_state.order_depths:
                continue
            od = trading_state.order_depths[product]
            mp = mid_price(od)
            if mp is None:
                continue

            prev_ema = state["ema"].get(product, mp)
            state["ema"][product] = EMA_ALPHA * mp + (1 - EMA_ALPHA) * prev_ema

            if product == "VELVETFRUIT_EXTRACT":
                prev_mid = state["prev_mid"].get(product)
                if prev_mid and prev_mid > 0:
                    ret_sq = (mp / prev_mid - 1) ** 2
                    state["vol_sq_sum"] += ret_sq
                    state["vol_n"] += 1
                    if state["vol_n"] > 10:
                        raw_var = state["vol_sq_sum"] / state["vol_n"]
                        state["vf_sigma"] = math.sqrt(raw_var * STEPS_PER_YEAR)
                state["prev_mid"][product] = mp

        sigma = max(0.01, state["vf_sigma"])

        # ── 3. TTE ──────────────────────────────────────────────────────────
        ts = trading_state.timestamp
        day = getattr(trading_state, 'day', 1)
        total_steps_elapsed = (day - 1) * STEPS_PER_DAY + ts / 100
        total_steps_remaining = max(1, VEV_DAYS_TOTAL * STEPS_PER_DAY - total_steps_elapsed)
        T_years = total_steps_remaining / STEPS_PER_YEAR

        # ── 4. Trade HYDROGEL_PACK ───────────────────────────────────────────
        if "HYDROGEL_PACK" in trading_state.order_depths:
            orders["HYDROGEL_PACK"] = self._trade_hydrogel(
                trading_state.order_depths["HYDROGEL_PACK"],
                positions.get("HYDROGEL_PACK", 0),
                state,
            )

        # ── 5. Trade VELVETFRUIT_EXTRACT ─────────────────────────────────────
        if "VELVETFRUIT_EXTRACT" in trading_state.order_depths:
            orders["VELVETFRUIT_EXTRACT"] = self._trade_velvetfruit(
                trading_state.order_depths["VELVETFRUIT_EXTRACT"],
                positions.get("VELVETFRUIT_EXTRACT", 0),
                state,
            )

        # ── 6. Trade VEV vouchers (THE MONEY MAKER) ─────────────────────────
        vf_mid = state["ema"].get("VELVETFRUIT_EXTRACT", 5248.0)
        vev_orders, vev_delta = self._trade_vevs(
            trading_state.order_depths,
            positions,
            vf_mid,
            sigma,
            T_years,
            state,
        )
        orders.update(vev_orders)

        # ── 7. Selective delta hedge (only when exposure is large) ───────────
        if abs(vev_delta) > DELTA_HEDGE_THRESHOLD:
            vev_hedge = self._delta_hedge_vev(
                vev_delta,
                trading_state.order_depths.get("VELVETFRUIT_EXTRACT"),
                positions.get("VELVETFRUIT_EXTRACT", 0),
                orders.get("VELVETFRUIT_EXTRACT", []),
            )
            if vev_hedge:
                orders["VELVETFRUIT_EXTRACT"] = (
                    orders.get("VELVETFRUIT_EXTRACT", []) + vev_hedge
                )

        state["timestamp"] = ts
        return orders, 0, save_state(state)

    # ── HYDROGEL_PACK ─────────────────────────────────────────────────────────

    def _trade_hydrogel(
        self,
        od: OrderDepth,
        position: int,
        state: dict,
    ) -> List[Order]:
        orders = []
        fair = state["ema"].get("HYDROGEL_PACK", 9994.0)

        last_buyer  = state["last_buyer"].get("HYDROGEL_PACK", "")
        last_seller = state["last_seller"].get("HYDROGEL_PACK", "")

        # Counterparty bias
        bias = 0
        if last_buyer == "Mark 38":
            bias = +2
        elif last_seller == "Mark 14":
            bias = -2

        fair_adj = fair + bias

        # Aggressive: sweep all mispriced levels
        if od.sell_orders:
            for ask_price in sorted(od.sell_orders):
                if ask_price < fair_adj - 1:  # tighter threshold
                    vol = min(-od.sell_orders[ask_price], available_buy("HYDROGEL_PACK", position))
                    if vol > 0:
                        orders.append(Order("HYDROGEL_PACK", ask_price, vol))
                        position += vol

        if od.buy_orders:
            for bid_price in sorted(od.buy_orders, reverse=True):
                if bid_price > fair_adj + 1:
                    vol = min(od.buy_orders[bid_price], available_sell("HYDROGEL_PACK", position))
                    if vol > 0:
                        orders.append(Order("HYDROGEL_PACK", bid_price, -vol))
                        position -= vol

        # Passive quotes — tighter spread, bigger size
        our_bid = int(fair_adj - HP_HALF_SPREAD)
        our_ask = int(fair_adj + HP_HALF_SPREAD)

        buy_qty  = min(HP_PASSIVE_SIZE, available_buy("HYDROGEL_PACK", position))
        sell_qty = min(HP_PASSIVE_SIZE, available_sell("HYDROGEL_PACK", position))

        if buy_qty > 0:
            orders.append(Order("HYDROGEL_PACK", our_bid, buy_qty))
        if sell_qty > 0:
            orders.append(Order("HYDROGEL_PACK", our_ask, -sell_qty))

        return orders

    # ── VELVETFRUIT_EXTRACT ───────────────────────────────────────────────────

    def _trade_velvetfruit(
        self,
        od: OrderDepth,
        position: int,
        state: dict,
    ) -> List[Order]:
        orders = []
        fair = state["ema"].get("VELVETFRUIT_EXTRACT", 5248.0)

        last_buyer  = state["last_buyer"].get("VELVETFRUIT_EXTRACT", "")
        last_seller = state["last_seller"].get("VELVETFRUIT_EXTRACT", "")

        bias = 0
        if last_buyer == "Mark 67":
            bias = +1
        elif last_buyer == "Mark 55":
            bias = -1
        elif last_seller == "Mark 55":
            bias = +1

        fair_adj = fair + bias

        # Aggressive sweep
        if od.sell_orders:
            for ask_price in sorted(od.sell_orders):
                if ask_price < fair_adj - 1:
                    vol = min(-od.sell_orders[ask_price], available_buy("VELVETFRUIT_EXTRACT", position))
                    if vol > 0:
                        orders.append(Order("VELVETFRUIT_EXTRACT", ask_price, vol))
                        position += vol

        if od.buy_orders:
            for bid_price in sorted(od.buy_orders, reverse=True):
                if bid_price > fair_adj + 1:
                    vol = min(od.buy_orders[bid_price], available_sell("VELVETFRUIT_EXTRACT", position))
                    if vol > 0:
                        orders.append(Order("VELVETFRUIT_EXTRACT", bid_price, -vol))
                        position -= vol

        # Passive — tighter, bigger
        our_bid = int(fair_adj - VF_HALF_SPREAD)
        our_ask = int(fair_adj + VF_HALF_SPREAD)

        buy_qty  = min(VF_PASSIVE_SIZE, available_buy("VELVETFRUIT_EXTRACT", position))
        sell_qty = min(VF_PASSIVE_SIZE, available_sell("VELVETFRUIT_EXTRACT", position))

        if buy_qty > 0:
            orders.append(Order("VELVETFRUIT_EXTRACT", our_bid, buy_qty))
        if sell_qty > 0:
            orders.append(Order("VELVETFRUIT_EXTRACT", our_ask, -sell_qty))

        return orders

    # ── VEV Vouchers (AGGRESSIVE SWEEP) ───────────────────────────────────────

    def _trade_vevs(
        self,
        order_depths: Dict[str, OrderDepth],
        positions: Dict[str, int],
        vf_mid: float,
        sigma: float,
        T_years: float,
        state: dict,
    ) -> Tuple[Dict[str, List[Order]], float]:
        """
        V2: Sweep ALL price levels in the VEV order books, not just best.
        Buy everything below (theory - edge), sell everything above (theory + edge).
        """
        all_orders: Dict[str, List[Order]] = {}
        total_delta = 0.0

        for K in VEV_STRIKES:
            sym = f"VEV_{K}"
            if sym not in order_depths:
                continue

            od     = order_depths[sym]
            pos    = positions.get(sym, 0)
            theory = black_scholes_call(vf_mid, K, T_years, sigma)
            delta  = bs_call_delta(vf_mid, K, T_years, sigma)

            vev_orders = []

            # === BUY SWEEP: lift every ask below (theory - edge) ===
            if od.sell_orders:
                for ask_price in sorted(od.sell_orders):
                    if ask_price < theory - VEV_EDGE:
                        avail = available_buy(sym, pos)
                        if avail <= 0:
                            break
                        qty = min(
                            -od.sell_orders[ask_price],
                            avail,
                            VEV_MAX_PER_LEVEL,
                        )
                        if qty > 0:
                            vev_orders.append(Order(sym, ask_price, qty))
                            total_delta += qty * delta
                            pos += qty
                    else:
                        break  # sorted, no more cheap asks

            # === SELL SWEEP: hit every bid above (theory + edge) ===
            if od.buy_orders:
                for bid_price in sorted(od.buy_orders, reverse=True):
                    if bid_price > theory + VEV_EDGE:
                        avail = available_sell(sym, pos)
                        if avail <= 0:
                            break
                        qty = min(
                            od.buy_orders[bid_price],
                            avail,
                            VEV_MAX_PER_LEVEL,
                        )
                        if qty > 0:
                            vev_orders.append(Order(sym, bid_price, -qty))
                            total_delta -= qty * delta
                            pos -= qty
                    else:
                        break

            # === Passive VEV quotes to capture spread ===
            # Place limit orders at theory ± edge to join the book
            passive_buy_price = int(theory - VEV_EDGE - 1)
            passive_sell_price = int(theory + VEV_EDGE + 1)
            passive_size = min(20, available_buy(sym, pos))
            if passive_size > 0 and passive_buy_price > 0:
                vev_orders.append(Order(sym, passive_buy_price, passive_size))
                pos += passive_size

            passive_sell_size = min(20, available_sell(sym, pos))
            if passive_sell_size > 0 and passive_sell_price > 0:
                vev_orders.append(Order(sym, passive_sell_price, -passive_sell_size))

            if vev_orders:
                all_orders[sym] = vev_orders

        return all_orders, total_delta

    # ── Delta Hedge (SELECTIVE) ───────────────────────────────────────────────

    def _delta_hedge_vev(
        self,
        vev_delta: float,
        od: Optional[OrderDepth],
        vf_position: int,
        existing_vf_orders: List[Order],
    ) -> List[Order]:
        """
        V2: Only hedge when delta exposure is large (>50).
        Partial hedge — aim to bring exposure to ±30, not zero.
        """
        if od is None:
            return []

        pending_vf = sum(o.quantity for o in existing_vf_orders)
        net_vf_pos = vf_position + pending_vf

        # Target: reduce exposure to ±30 instead of zero
        target = 30 if vev_delta > 0 else -30
        hedge_qty = int(round(-vev_delta + target - net_vf_pos))
        if abs(hedge_qty) < 10:
            return []

        orders = []
        if hedge_qty > 0:
            hedge_qty = min(hedge_qty, available_buy("VELVETFRUIT_EXTRACT", net_vf_pos))
            if od.sell_orders and hedge_qty > 0:
                # Sweep available asks
                for ask_price in sorted(od.sell_orders):
                    if hedge_qty <= 0:
                        break
                    take = min(-od.sell_orders[ask_price], hedge_qty)
                    if take > 0:
                        orders.append(Order("VELVETFRUIT_EXTRACT", ask_price, take))
                        hedge_qty -= take
        else:
            hedge_qty = min(-hedge_qty, available_sell("VELVETFRUIT_EXTRACT", net_vf_pos))
            if od.buy_orders and hedge_qty > 0:
                for bid_price in sorted(od.buy_orders, reverse=True):
                    if hedge_qty <= 0:
                        break
                    take = min(od.buy_orders[bid_price], hedge_qty)
                    if take > 0:
                        orders.append(Order("VELVETFRUIT_EXTRACT", bid_price, -take))
                        hedge_qty -= take

        return orders