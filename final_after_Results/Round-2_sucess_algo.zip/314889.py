from datamodel import OrderDepth, UserId, TradingState, Order
from typing import List

class Trader:
    """
    V4 - Round 2 Strategy "Limited Market Access"
    - Osmium: Safe mean-reversion around 10000.
    - Pepper Root: Abuses the 1,000 point/day trend by taking/holding maximum long position.
    - MAF: Implements the bid() function to pay a Market Access Fee.
    """
    def __init__(self):
        self.limits = {
            "ASH_COATED_OSMIUM": 80,
            "INTARIAN_PEPPER_ROOT": 80
        }

    def bid(self):
        """
        Market Access Fee (MAF) bid for Round 2.
        We estimate a flat fee to get into the top 50% of participants for 25% extra order volume.
        """
        return 1500  # You can tweak this value. It is subtracted from Rd 2 profits if accepted.

    def run(self, state: TradingState):
        result = {}
        
        for product, order_depth in state.order_depths.items():
            orders: List[Order] = []
            position = state.position.get(product, 0)
            limit = self.limits.get(product, 80)
            
            best_bid = max(order_depth.buy_orders.keys()) if len(order_depth.buy_orders) > 0 else None
            best_ask = min(order_depth.sell_orders.keys()) if len(order_depth.sell_orders) > 0 else None
            
            if best_bid is None or best_ask is None:
                continue
                
            if product == "ASH_COATED_OSMIUM":
                fv = 10000
                
                # ---- PHASE 1: MARKET TAKING ----
                for ask, ask_vol in sorted(order_depth.sell_orders.items()):
                    if ask < fv and position < limit:
                        buy_vol = min(limit - position, -ask_vol)
                        if buy_vol > 0:
                            orders.append(Order(product, ask, buy_vol))
                            position += buy_vol
                            
                for bid, bid_vol in sorted(order_depth.buy_orders.items(), reverse=True):
                    if bid > fv and position > -limit:
                        sell_vol = max(-limit - position, -bid_vol)
                        if sell_vol < 0:
                            orders.append(Order(product, bid, sell_vol))
                            position += sell_vol
                            
                # ---- PHASE 2: MARKET MAKING ----
                skew = -int((position / limit) * 3) 
                my_bid = fv - 2 + skew
                my_ask = fv + 2 + skew
                
                my_bid = min(my_bid, best_bid + 1)
                my_ask = max(my_ask, best_ask - 1)
                
                if position < limit:
                    orders.append(Order(product, my_bid, limit - position))
                if position > -limit:
                    orders.append(Order(product, my_ask, -limit - position))
                    
            elif product == "INTARIAN_PEPPER_ROOT":
                # STRATEGY: Trend is perfectly linear +1000/day. Max Long
                buy_cap = limit - position
                
                for ask, ask_vol in sorted(order_depth.sell_orders.items()):
                    if buy_cap <= 0:
                        break
                    available = -ask_vol
                    qty = min(buy_cap, available)
                    if qty > 0:
                        orders.append(Order(product, ask, qty))
                        buy_cap -= qty
                
                if buy_cap > 0:
                    orders.append(Order(product, best_bid + 1, buy_cap))
                    
            result[product] = orders
            
        conversions = 0
        traderData = ""
        return result, conversions, traderData